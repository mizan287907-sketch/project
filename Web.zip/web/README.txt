Emergency Guard / জরুরি সুরক্ষা — Web App (Android, iPhone, Laptop)

ONLINE করার সবচেয়ে সহজ উপায় (বিনামূল্যে, ২ মিনিট):
1) https://app.netlify.com/drop খুলুন  2) এই ফোল্ডারটা (Web) টেনে ছেড়ে দিন  3) একটা https লিংক পাবেন।
(GitHub Pages / Cloudflare Pages / Vercel-ও চলবে)। অবশ্যই https লিংক লাগবে, নইলে মাইক/লোকেশন চলবে না।

ইনস্টল:
- Android (Chrome): লিংক খুলুন → মেনু ⋮ → "Install app"
- iPhone (Safari):  লিংক খুলুন → Share → "Add to Home Screen"
- Laptop (Chrome/Edge): ঠিকানার ডান পাশে Install আইকন
