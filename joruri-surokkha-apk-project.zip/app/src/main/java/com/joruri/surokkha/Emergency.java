package com.joruri.surokkha;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import java.util.ArrayList;
import java.util.List;

/** জরুরি অবস্থায় নিজে থেকে SMS পাঠায় এবং এক এক করে কল করে। */
class Emergency extends BroadcastReceiver {

    interface Report { void on(String kind, String value); }

    private final Activity act;
    private final Report report;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private List<String> nums = new ArrayList<>();
    private int idx = 0;
    private long offhookAt = 0;
    private boolean active = false;

    Emergency(Activity act, Report report) {
        this.act = act;
        this.report = report;
    }

    /** কল শেষ হওয়ার খবর পেতে হলে এটি চালু রাখতে হয়। */
    void register() {
        android.content.IntentFilter f = new android.content.IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            act.registerReceiver(this, f, Context.RECEIVER_EXPORTED);
        } else {
            act.registerReceiver(this, f);
        }
    }

    void unregister() {
        try { act.unregisterReceiver(this); } catch (Exception ignored) { }
        handler.removeCallbacksAndMessages(null);
    }

    void start(List<String> numbers, String message) {
        cancel();
        nums = numbers;
        idx = 0;
        offhookAt = 0;
        active = true;
        sendSms(message);
        callNext();
    }

    void cancel() {
        active = false;
        handler.removeCallbacksAndMessages(null);
    }

    @SuppressLint("MissingPermission")
    private void sendSms(String message) {
        int ok = 0;
        try {
            SmsManager sm;
            if (Build.VERSION.SDK_INT >= 31) {
                sm = act.getSystemService(SmsManager.class);
            } else {
                sm = SmsManager.getDefault();
            }
            ArrayList<String> parts = sm.divideMessage(message);
            for (String n : nums) {
                try {
                    sm.sendMultipartTextMessage(n, null, parts, null, null);
                    ok++;
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        report.on(ok > 0 ? "sms" : "smsfail", String.valueOf(ok));
    }

    @SuppressLint("MissingPermission")
    private void callNext() {
        if (!active || idx >= nums.size()) {
            active = false;
            return;
        }
        final String n = nums.get(idx);
        idx++;
        final int mine = idx;
        offhookAt = 0;
        Uri uri = Uri.fromParts("tel", n, null);
        boolean placed = false;
        try {
            TelecomManager tm = (TelecomManager) act.getSystemService(Context.TELECOM_SERVICE);
            tm.placeCall(uri, new Bundle());
            placed = true;
        } catch (Exception ignored) { }
        if (!placed) {
            try {
                Intent i = new Intent(Intent.ACTION_CALL, uri);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(i);
                placed = true;
            } catch (Exception ignored) { }
        }
        report.on(placed ? "call" : "callfail", String.valueOf(mine));
        // কল শুরুই না হলে ১৫ সেকেন্ড পর পরের নম্বরে যাবে
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (active && idx == mine && offhookAt == 0) callNext();
            }
        }, 15000);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!active) return;
        String s = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (s == null) return;
        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(s)) {
            if (offhookAt == 0) offhookAt = System.currentTimeMillis();
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(s)) {
            if (offhookAt > 0) {
                long dur = System.currentTimeMillis() - offhookAt;
                offhookAt = 0;
                // ২৫ সেকেন্ডের কম হলে ধরে নেওয়া হয় ধরেননি → পরের জনকে কল
                if (dur < 25000 && idx < nums.size()) {
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { callNext(); }
                    }, 2500);
                } else {
                    active = false;
                }
            }
        }
    }
}
