package com.example.joruri

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*

class AlarmActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var title: TextView
    private lateinit var count: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#B91C1C")); setPadding(40, 120, 40, 60)
        }
        title = TextView(this).apply { textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        count = TextView(this).apply { textSize = 90f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val ok = Button(this).apply {
            text = "✅ আমি ঠিক আছি"; textSize = 24f
            setOnClickListener {
                startService(Intent(this@AlarmActivity, GuardService::class.java).setAction(GuardService.A_OK)); finish()
            }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(count, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(ok, LinearLayout.LayoutParams(-1, 220))
        setContentView(root)
        poll.run()
    }

    private val poll = object : Runnable {
        override fun run() {
            when (GuardService.state) {
                0 -> { finish(); return }
                1 -> { title.text = GuardService.alertText; count.text = GuardService.left.toString() }
                else -> { title.text = "🚨 জরুরি! SMS পাঠানো হয়েছে, কল করা হচ্ছে"; count.text = "" }
            }
            h.postDelayed(this, 500)
        }
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
