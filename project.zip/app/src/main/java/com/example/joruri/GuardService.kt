package com.example.joruri

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs
import kotlin.math.sqrt

class GuardService : Service(), SensorEventListener {
    companion object {
        const val A_OK = "ok"; const val A_TEST = "test"; const val A_STOP = "stop"
        @Volatile var running = false
        @Volatile var state = 0      // 0 = স্বাভাবিক, 1 = জিজ্ঞাসা, 2 = জরুরি
        @Volatile var left = 0
        @Volatile var info = ""
        @Volatile var alertText = ""
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var wl: PowerManager.WakeLock? = null
    private var ringtone: Ringtone? = null
    private var lastLoc: Location? = null
    private var impactAt = 0L
    private var still = 0
    private var lastB = 0L
    private val bursts = ArrayList<Long>()
    private var started = false
    private val KW = listOf("বাঁচাও", "বাচাও", "সাহায্য", "বুকে ব্যথা", "বুকে কষ্ট", "শ্বাস", "কষ্ট হচ্ছে", "মরে গেলাম", "মরে যাচ্ছি")
    private val SHORT = listOf("আহ", "উহ", "help")

    private val locL = object : LocationListener {
        override fun onLocationChanged(l: Location) { lastLoc = l }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guard", "সুরক্ষা চালু", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alarm", "জরুরি অ্যালার্ম", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = NotificationCompat.Builder(this, "guard").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("জরুরি সুরক্ষা চালু আছে").setContentText("পড়ে যাওয়া ও সাহায্যের ডাক শোনা হচ্ছে").setOngoing(true).build()
        var type = 0
        if (Build.VERSION.SDK_INT >= 29) {
            if (has("android.permission.RECORD_AUDIO")) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (has("android.permission.ACCESS_FINE_LOCATION")) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        try { ServiceCompat.startForeground(this, 1, n, type) } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }

        when (intent?.action) {
            A_STOP -> { stopSelf(); return START_NOT_STICKY }
            A_OK -> cancelAlarm()
            A_TEST -> { begin(); trigger("পরীক্ষা (টেস্ট অ্যালার্ম)") }
            else -> begin()
        }
        return START_STICKY
    }

    private fun begin() {
        if (started) return
        started = true
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joruri:guard").apply { acquire() }
        val sm = getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (has("android.permission.ACCESS_FINE_LOCATION")) {
            val lm = getSystemService(LocationManager::class.java)
            try {
                for (pv in lm.getProviders(true)) lm.requestLocationUpdates(pv, 60000L, 0f, locL, Looper.getMainLooper())
            } catch (e: Exception) {}
        }
        if (has("android.permission.RECORD_AUDIO")) startSR() else info = "মাইকের অনুমতি নেই — শুধু পড়ে যাওয়া শনাক্ত হবে"
    }

    // ১) পড়ে যাওয়া শনাক্ত
    override fun onSensorChanged(e: SensorEvent) {
        if (state != 0) return
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.8f
        val now = System.currentTimeMillis()
        if (g > 3f) { impactAt = now; still = 0 }
        else if (impactAt != 0L && now - impactAt < 6000 && abs(g - 1f) < 0.08f) still++
        if (impactAt != 0L && now - impactAt >= 6000) {
            if (still > 30) trigger("জোরে ধাক্কা লেগেছে, তারপর নড়াচড়া নেই")
            impactAt = 0; still = 0
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // ২) কথা ও শব্দ শনাক্ত
    private fun startSR() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { info = "এই ফোনে কথা শনাক্তকরণ নেই"; return }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onRmsChanged(rms: Float) {
                val now = System.currentTimeMillis()
                if (state == 0 && rms > 9f && now - lastB > 700) {
                    lastB = now; bursts.add(now); bursts.removeAll { now - it > 15000 }
                    if (bursts.size >= 4) { bursts.clear(); trigger("বারবার জোরালো কষ্টের মতো শব্দ") }
                }
            }
            override fun onError(e: Int) { relisten() }
            override fun onResults(r: Bundle?) { check(r); relisten() }
            override fun onPartialResults(r: Bundle?) { check(r) }
        })
        listen()
    }

    private fun check(r: Bundle?) {
        if (state != 0) return
        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: return
        info = "শুনেছি: $t"
        if (KW.any { t.contains(it) } || t.split(Regex("\\s+")).any { it in SHORT }) trigger("সাহায্যের কথা শনাক্ত: $t")
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        try { sr?.startListening(i) } catch (e: Exception) {}
    }
    private fun relisten() { if (running) h.postDelayed({ listen() }, 400) }

    // অ্যালার্ম
    private fun prefs() = getSharedPreferences("p", 0)

    private fun trigger(reason: String) {
        if (state != 0) return
        state = 1
        left = if (prefs().getBoolean("f", false)) 8 else 30
        alertText = prefs().getString("t", "আপনি কি ঠিক আছেন?") ?: "আপনি কি ঠিক আছেন?"
        info = "⚠️ $reason"
        siren(true)
        val i = Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ জরুরি অ্যালার্ম").setContentText(alertText).setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM).setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
        try { startActivity(i) } catch (e: Exception) {}
        h.postDelayed(tickR, 1000)
    }

    private val tickR = object : Runnable {
        override fun run() {
            if (state != 1) return
            left--
            if (left <= 0) emergency() else h.postDelayed(this, 1000)
        }
    }

    private fun cancelAlarm() {
        h.removeCallbacks(tickR); siren(false); state = 0; left = 0; info = "✅ ব্যক্তি সাড়া দিয়েছেন"
        getSystemService(NotificationManager::class.java).cancel(2)
    }

    private fun location(): String {
        var best = lastLoc
        try {
            val lm = getSystemService(LocationManager::class.java)
            for (pv in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(pv) ?: continue
                if (best == null || l.time > best.time) best = l
            }
        } catch (e: SecurityException) {}
        return best?.let { "https://maps.google.com/?q=${it.latitude},${it.longitude}" } ?: "পাওয়া যায়নি"
    }

    private fun emergency() {
        state = 2
        info = "🚨 সাড়া আসেনি — SMS ও কল"
        val list = (0 until 5).map { prefs().getString("p$it", "") ?: "" }.map { it.replace(Regex("[\\s-]"), "") }.filter { it.isNotEmpty() }
        val msg = "জরুরি! আপনার পরিচিত ব্যক্তি গুরুতর অসুস্থ বা অজ্ঞান হয়ে পড়তে পারেন। দ্রুত যোগাযোগ করুন বা অ্যাম্বুলেন্স ডাকুন। লোকেশন: " + location()
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sms.divideMessage(msg)
            list.forEach { try { sms.sendMultipartTextMessage(it, null, parts, null, null) } catch (e: Exception) {} }
        } catch (e: Exception) {}
        if (list.isNotEmpty()) {
            try { getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", list[0], null), Bundle()) } catch (e: Exception) {}
        }
    }

    private fun siren(on: Boolean) {
        val vib = getSystemService(Vibrator::class.java)
        if (!on) { ringtone?.stop(); ringtone = null; vib.cancel(); return }
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
            audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            isLooping = true; play()
        }
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 300, 200, 300, 600), 0))
    }

    override fun onDestroy() {
        running = false; state = 0; info = ""
        h.removeCallbacksAndMessages(null); siren(false)
        try { sr?.destroy() } catch (e: Exception) {}
        try { getSystemService(SensorManager::class.java).unregisterListener(this) } catch (e: Exception) {}
        try { getSystemService(LocationManager::class.java).removeUpdates(locL) } catch (e: Exception) {}
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}
        super.onDestroy()
    }
}
