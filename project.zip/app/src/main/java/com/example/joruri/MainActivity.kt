package com.example.joruri

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private val names = ArrayList<EditText>()
    private val nums = ArrayList<EditText>()
    private lateinit var atext: EditText
    private lateinit var fast: CheckBox
    private lateinit var toggle: Button
    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())
    private var pendingTest = false

    private val perms: Array<String> get() {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 70, 40, 40); setBackgroundColor(Color.parseColor("#0B1220"))
        }
        fun tv(t: String, s: Float = 16f) = TextView(this).apply { text = t; textSize = s; setTextColor(Color.WHITE) }
        fun et(hint: String, v: String) = EditText(this).apply {
            this.hint = hint; setText(v); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(tv("🛡️ জরুরি সুরক্ষা", 26f))
        status = tv("", 15f); root.addView(status)
        root.addView(tv("\nজরুরি নম্বর (সর্বোচ্চ ৫টি, প্রথমটিতে কল যাবে):", 14f))
        for (i in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val n = et("নাম", p.getString("n$i", "") ?: "")
            val m = et("নম্বর", p.getString("p$i", "") ?: "").apply { inputType = android.text.InputType.TYPE_CLASS_PHONE }
            row.addView(n, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(m, LinearLayout.LayoutParams(0, -2, 1.3f))
            names.add(n); nums.add(m); root.addView(row)
        }
        atext = et("অ্যালার্মের লেখা", p.getString("t", "আপনি কি ঠিক আছেন? বোতাম চাপুন") ?: "")
        root.addView(atext)
        fast = CheckBox(this).apply { text = "দ্রুত মোড (৮ সেকেন্ড, পরীক্ষার জন্য)"; setTextColor(Color.LTGRAY); isChecked = p.getBoolean("f", false) }
        root.addView(fast)
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle, LinearLayout.LayoutParams(-1, 180))
        root.addView(Button(this).apply { text = "⚠️ পরীক্ষা অ্যালার্ম"; setOnClickListener { onTest() } })
        root.addView(tv("\nসহায়ক টুল — ডাক্তারি নির্ণয় বা ৯৯৯-এর বিকল্প নয়", 12f))
        setContentView(ScrollView(this).apply { addView(root) })
        tick.run()
    }

    private val tick = object : Runnable {
        override fun run() {
            val on = GuardService.running
            toggle.text = if (on) "সুরক্ষা বন্ধ করুন" else "সুরক্ষা চালু করুন"
            status.text = if (on) "✅ সুরক্ষা চালু আছে" + (if (GuardService.info.isNotEmpty()) "\n" + GuardService.info else "") else "সুরক্ষা বন্ধ"
            h.postDelayed(this, 1000)
        }
    }

    private fun saveAll() {
        val e = p.edit()
        for (i in 0 until 5) { e.putString("n$i", names[i].text.toString().trim()); e.putString("p$i", nums[i].text.toString().trim()) }
        e.putString("t", atext.text.toString()).putBoolean("f", fast.isChecked).apply()
    }

    private fun missing() = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun begin(action: String?) {
        saveAll()
        val i = Intent(this, GuardService::class.java)
        if (action != null) i.action = action
        startForegroundService(i)
    }

    private fun onToggle() {
        if (GuardService.running) { begin(GuardService.A_STOP); return }
        pendingTest = false
        val m = missing()
        if (m.isEmpty()) begin(null) else requestPermissions(m.toTypedArray(), 1)
    }

    private fun onTest() {
        pendingTest = true
        val m = missing()
        if (m.isEmpty()) begin(GuardService.A_TEST) else requestPermissions(m.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, ps: Array<out String>, gr: IntArray) {
        super.onRequestPermissionsResult(rc, ps, gr)
        if (missing().isNotEmpty()) Toast.makeText(this, "কিছু অনুমতি দেওয়া হয়নি — সব অনুমতি দিলে ভালো কাজ করবে", Toast.LENGTH_LONG).show()
        begin(if (pendingTest) GuardService.A_TEST else null)
    }

    override fun onPause() { super.onPause(); saveAll() }
    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
