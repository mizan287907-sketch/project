package com.joruri.surokkha;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** জরুরি অবস্থায় নিজে থেকে SMS পাঠায় (লোকেশন লিংকসহ) এবং এক এক করে কল করে। */
class Emergency extends BroadcastReceiver {

    interface Report { void on(String kind, String value); }

    private final Activity act;
    private final Report report;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private List<String> nums = new ArrayList<>();
    private int idx = 0;
    private long offhookAt = 0;
    private boolean active = false;

    // ---- লোকেশন (সরাসরি Android থেকে, WebView-এর উপর নির্ভর না করে) ----
    private static final long FRESH_MS = 2 * 60 * 1000L;   // এর চেয়ে নতুন হলে "তাজা" ধরা হয়
    private static final long FOLLOW_MS = 3 * 60 * 1000L;  // তাজা লোকেশনের জন্য এতক্ষণ অপেক্ষা
    private static final String NO_LOC = "পাওয়া যায়নি";

    private final LocationManager lm;
    private Location best;          // এখন পর্যন্ত জানা সেরা/নতুন লোকেশন
    private boolean watching = false; // সুরক্ষা চালু থাকলে true
    private boolean followUp = false; // তাজা লোকেশন এলে আলাদা SMS যাবে

    private final LocationListener ll = new LocationListener() {
        @Override public void onLocationChanged(Location l) {
            consider(l);
            if (followUp && best != null
                    && System.currentTimeMillis() - best.getTime() < FRESH_MS) {
                followUp = false;
                sendSms("জরুরি আপডেট: ওই ব্যক্তির বর্তমান লোকেশন: " + link(best));
                if (!watching) unlisten();
            }
        }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
        @Override public void onProviderEnabled(String provider) { }
        @Override public void onProviderDisabled(String provider) { }
    };

    private final Runnable endFollow = new Runnable() {
        @Override public void run() {
            followUp = false;
            if (!watching) unlisten();
        }
    };

    Emergency(Activity act, Report report) {
        this.act = act;
        this.report = report;
        this.lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
    }

    private boolean hasLoc() {
        return act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || act.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** ফোনের লোকেশন সেবা (GPS/নেটওয়ার্ক) চালু আছে কিনা। */
    boolean locationEnabled() {
        if (lm == null) return false;
        try {
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    /** সুরক্ষা চালু/বন্ধ হলে ডাকা হয়: চালু থাকলে লোকেশন তাজা রাখে। */
    void watch(boolean on) {
        watching = on;
        if (on) listen();
        else if (!followUp) unlisten();
    }

    @SuppressLint("MissingPermission")
    private void listen() {
        if (lm == null || !hasLoc()) return;
        seed();
        String[] providers = { LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER };
        for (String p : providers) {
            try {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 20000L, 0f, ll, Looper.getMainLooper());
                }
            } catch (Exception ignored) { }
        }
    }

    private void unlisten() {
        if (lm == null) return;
        try { lm.removeUpdates(ll); } catch (Exception ignored) { }
    }

    /** ফোনে আগে থেকে জানা সর্বশেষ লোকেশন তুলে নেয় (ঘরের ভেতরেও পাওয়া যায়)। */
    @SuppressLint("MissingPermission")
    private void seed() {
        if (lm == null || !hasLoc()) return;
        String[] providers = { LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER,
                LocationManager.PASSIVE_PROVIDER };
        for (String p : providers) {
            try { consider(lm.getLastKnownLocation(p)); } catch (Exception ignored) { }
        }
    }

    private void consider(Location l) {
        if (l == null) return;
        long now = System.currentTimeMillis();
        if (best == null) { best = l; return; }
        boolean newer = l.getTime() >= best.getTime();
        boolean bestFresh = now - best.getTime() < 60000L;
        // নতুন কিন্তু অনেক কম নির্ভুল হলে (যেমন GPS-এর পর নেটওয়ার্ক) তাজা ভালোটাই রাখা হয়
        if (newer && !(bestFresh && l.getAccuracy() > best.getAccuracy() * 3 + 50)) best = l;
        else if (!newer && bestFresh && l.getTime() > now - 60000L && l.getAccuracy() < best.getAccuracy()) best = l;
    }

    private static String link(Location l) {
        return String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f", l.getLatitude(), l.getLongitude());
    }

    /** কল শেষ হওয়ার খবর পেতে হলে এটি চালু রাখতে হয়। */
    void register() {
        android.content.IntentFilter f = new android.content.IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            act.registerReceiver(this, f, Context.RECEIVER_EXPORTED);
        } else {
            act.registerReceiver(this, f);
        }
    }

    void unregister() {
        try { act.unregisterReceiver(this); } catch (Exception ignored) { }
        handler.removeCallbacksAndMessages(null);
        unlisten();
    }

    /**
     * message-এর ভেতরের {LOC} জায়গায় লোকেশন-লিংক বসে। পেজ থেকে পাওয়া লিংক (jsLink) শুধু শেষ ভরসা।
     * লোকেশন না থাকলে বা পুরোনো হলে SMS আগে চলে যায়, কল শুরু হয়, আর নতুন লোকেশন পেলে আলাদা SMS যায়।
     */
    void start(List<String> numbers, String message, String jsLink) {
        cancel();
        nums = numbers;
        idx = 0;
        offhookAt = 0;
        active = true;

        listen(); // সর্বশেষ জানা লোকেশন তুলে নেয় ও নতুন লোকেশন চাইতে থাকে
        String link = null;
        boolean fresh = false;
        if (best != null) {
            link = link(best);
            fresh = System.currentTimeMillis() - best.getTime() < FRESH_MS;
        } else if (jsLink != null && jsLink.startsWith("https://")) {
            link = jsLink;
            fresh = true;
        }
        String shown = link == null ? NO_LOC : (fresh ? link : link + " (সর্বশেষ জানা অবস্থান)");
        sendSms(message.replace("{LOC}", shown));
        callNext();

        if (link == null || !fresh) {
            followUp = true;
            handler.postDelayed(endFollow, FOLLOW_MS);
        }
    }

    void cancel() {
        active = false;
        followUp = false;
        handler.removeCallbacksAndMessages(null);
        if (!watching) unlisten();
    }

    @SuppressLint("MissingPermission")
    private void sendSms(String message) {
        int ok = 0;
        try {
            SmsManager sm;
            if (Build.VERSION.SDK_INT >= 31) {
                sm = act.getSystemService(SmsManager.class);
            } else {
                sm = SmsManager.getDefault();
            }
            ArrayList<String> parts = sm.divideMessage(message);
            for (String n : nums) {
                try {
                    sm.sendMultipartTextMessage(n, null, parts, null, null);
                    ok++;
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        report.on(ok > 0 ? "sms" : "smsfail", String.valueOf(ok));
    }

    @SuppressLint("MissingPermission")
    private void callNext() {
        if (!active || idx >= nums.size()) {
            active = false;
            return;
        }
        final String n = nums.get(idx);
        idx++;
        final int mine = idx;
        offhookAt = 0;
        Uri uri = Uri.fromParts("tel", n, null);
        boolean placed = false;
        try {
            TelecomManager tm = (TelecomManager) act.getSystemService(Context.TELECOM_SERVICE);
            tm.placeCall(uri, new Bundle());
            placed = true;
        } catch (Exception ignored) { }
        if (!placed) {
            try {
                Intent i = new Intent(Intent.ACTION_CALL, uri);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(i);
                placed = true;
            } catch (Exception ignored) { }
        }
        report.on(placed ? "call" : "callfail", String.valueOf(mine));
        // কল শুরুই না হলে ১৫ সেকেন্ড পর পরের নম্বরে যাবে
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (active && idx == mine && offhookAt == 0) callNext();
            }
        }, 15000);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!active) return;
        String s = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (s == null) return;
        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(s)) {
            if (offhookAt == 0) offhookAt = System.currentTimeMillis();
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(s)) {
            if (offhookAt > 0) {
                long dur = System.currentTimeMillis() - offhookAt;
                offhookAt = 0;
                // ২৫ সেকেন্ডের কম হলে ধরে নেওয়া হয় ধরেননি → পরের জনকে কল
                if (dur < 25000 && idx < nums.size()) {
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { callNext(); }
                    }, 2500);
                } else {
                    active = false;
                }
            }
        }
    }
}
