package com.joruri.surokkha;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILE = 11;
    private static final int REQ_PERM = 12;

    private static final String[] PERMS = {
            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Emergency emergency;
    private VoiceListener voice;
    private boolean voiceWanted = false;
    private boolean locWanted = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true);
        getWindow().setStatusBarColor(Color.parseColor("#0B1220"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B1220"));

        emergency = new Emergency(this, new Emergency.Report() {
            @Override public void on(String kind, String value) { toJs(kind, value); }
        });
        emergency.register();

        voice = new VoiceListener(this, new VoiceListener.Sink() {
            @Override public void speech(final String json, final boolean fin) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (web != null) web.evaluateJavascript("window.onSpeech&&window.onSpeech(" + json + "," + fin + ")", null);
                    }
                });
            }
            @Override public void error(String code) { toJs("voiceerr", code); }
        });

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B1220"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, has(Manifest.permission.ACCESS_FINE_LOCATION), false);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (has(Manifest.permission.RECORD_AUDIO)) req.grant(req.getResources());
                        else req.deny();
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        askMissing();
        web.loadUrl(START_URL);
    }

    private void toJs(final String kind, final String value) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web != null) {
                    web.evaluateJavascript("window.onNative&&window.onNative('" + kind + "','" + value + "')", null);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (voiceWanted && has(Manifest.permission.RECORD_AUDIO) && !voice.isRunning()) voice.start();
        if (locWanted) emergency.watch(true); // অনুমতি দেওয়ার পর লোকেশন নেওয়া শুরু
    }

    private boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void askMissing() {
        List<String> need = new ArrayList<>();
        for (String p : PERMS) if (!has(p)) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        // অ্যাপ বন্ধ না করে পেছনে পাঠায়, যাতে সুরক্ষা চলতে থাকে
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (voice != null) voice.stop();
        if (emergency != null) emergency.unregister();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** পেজ (JavaScript) থেকে ডাকা হয়। */
    private class Bridge {
        @JavascriptInterface
        public boolean hasPerms() {
            return has(Manifest.permission.SEND_SMS) && has(Manifest.permission.CALL_PHONE);
        }

        @JavascriptInterface
        public void askPerms() {
            runOnUiThread(new Runnable() {
                @Override public void run() { askMissing(); }
            });
        }

        @JavascriptInterface
        public void emergency(String numbersJson, String message, String jsLink) {
            try {
                JSONArray a = new JSONArray(numbersJson);
                List<String> list = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) {
                    String n = a.getString(i).trim();
                    if (!n.isEmpty()) list.add(n);
                }
                if (!list.isEmpty()) emergency.start(list, message, jsLink);
            } catch (Exception ignored) { }
        }

        /** সুরক্ষা চালু হলে লোকেশন তাজা রাখা শুরু। */
        @JavascriptInterface
        public void startLoc() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    locWanted = true;
                    emergency.watch(true);
                }
            });
        }

        @JavascriptInterface
        public void stopLoc() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    locWanted = false;
                    emergency.watch(false);
                }
            });
        }

        /** ফোনের লোকেশন (GPS/নেটওয়ার্ক) চালু আছে কিনা। */
        @JavascriptInterface
        public boolean locOn() {
            return emergency.locationEnabled();
        }

        @JavascriptInterface
        public void startListen() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    voiceWanted = true;
                    if (!has(Manifest.permission.RECORD_AUDIO)) {
                        askMissing();
                        toJs("voiceerr", "perm");
                        return;
                    }
                    voice.start();
                }
            });
        }

        @JavascriptInterface
        public void stopListen() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    voiceWanted = false;
                    voice.stop();
                }
            });
        }

        @JavascriptInterface
        public void cancelEmergency() {
            emergency.cancel();
        }
    }
}
