package com.joruri.surokkha;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import org.json.JSONArray;

import java.util.ArrayList;

/** ফোনের Google কথা-শনাক্ত সার্ভিস দিয়ে বাংলা কথা শোনে (বারবার নিজে থেকে চালু হয়)। */
class VoiceListener implements RecognitionListener {

    interface Sink {
        void speech(String jsonArray, boolean fin);
        void error(String code);
    }

    private final Activity act;
    private final Sink sink;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final AudioManager am;
    private final Intent intent;

    private SpeechRecognizer sr;
    private boolean running = false;
    private boolean netReported = false;

    VoiceListener(Activity act, Sink sink) {
        this.act = act;
        this.sink = sink;
        this.am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.getPackageName());
    }

    boolean isRunning() { return running; }

    void start() {
        if (running) return;
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            sink.error("unavailable");
            return;
        }
        running = true;
        netReported = false;
        mute(true);
        create();
        listen();
    }

    void stop() {
        running = false;
        h.removeCallbacksAndMessages(null);
        destroy();
        mute(false);
    }

    private void create() {
        destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(act);
        sr.setRecognitionListener(this);
    }

    private void destroy() {
        if (sr != null) {
            try { sr.cancel(); } catch (Exception ignored) { }
            try { sr.destroy(); } catch (Exception ignored) { }
            sr = null;
        }
    }

    private void listen() {
        if (!running || sr == null) return;
        try {
            sr.startListening(intent);
        } catch (Exception e) {
            again(1500, true);
        }
    }

    private void again(long delay, final boolean recreate) {
        h.removeCallbacksAndMessages(null);
        h.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running) return;
                if (recreate || sr == null) create();
                listen();
            }
        }, delay);
    }

    /** প্রতিবার শোনা শুরুর "টুং" শব্দ চাপা দিতে নোটিফিকেশন/সিস্টেম স্ট্রিম মিউট রাখা হয়। */
    private void mute(boolean m) {
        int[] streams = {AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM};
        for (int s : streams) {
            try {
                am.adjustStreamVolume(s, m ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, 0);
            } catch (Exception ignored) { }
        }
    }

    private void send(Bundle b, boolean fin) {
        if (b == null) return;
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r == null || r.isEmpty()) return;
        JSONArray ja = new JSONArray();
        for (String t : r) ja.put(t);
        sink.speech(ja.toString(), fin);
    }

    @Override public void onResults(Bundle results) {
        send(results, true);
        if (running) again(300, false);
    }

    @Override public void onPartialResults(Bundle partialResults) {
        send(partialResults, false);
    }

    @Override public void onError(int error) {
        if (!running) return;
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            running = false;
            mute(false);
            sink.error("perm");
        } else if (error == SpeechRecognizer.ERROR_NETWORK
                || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                || error == SpeechRecognizer.ERROR_SERVER) {
            if (!netReported) {
                netReported = true;
                sink.error("net");
            }
            again(3000, true);
        } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                || error == SpeechRecognizer.ERROR_CLIENT
                || error == SpeechRecognizer.ERROR_AUDIO) {
            again(1200, true);
        } else {
            // কথা পাওয়া যায়নি / সময় শেষ — আবার শোনা শুরু
            again(400, false);
        }
    }

    @Override public void onReadyForSpeech(Bundle params) { }
    @Override public void onBeginningOfSpeech() { }
    @Override public void onRmsChanged(float rmsdB) { }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { }
    @Override public void onEvent(int eventType, Bundle params) { }
}
