package com.joruri.surokkha;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * সুরক্ষা চালু থাকলে স্ট্যাটাস বারে নোটিফিকেশন দেখায় এবং অ্যাপকে চালু রাখে,
 * যাতে স্ক্রিন বন্ধ থাকলেও মাইক, লোকেশন ও কাজ বন্ধ না হয়।
 */
public class GuardService extends Service {

    private static final String CH = "guard";
    private static final int ID = 7;

    private PowerManager.WakeLock wl;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, GuardService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, GuardService.class));
        } catch (Exception ignored) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForegroundCompat();
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joruri:guard");
                wl.setReferenceCounted(false);
            }
            // স্ক্রিন বন্ধ থাকলেও CPU জাগিয়ে রাখে (১২ ঘণ্টা পরপর নবায়ন)
            wl.acquire(12 * 60 * 60 * 1000L);
        } catch (Exception ignored) { }
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "সুরক্ষা চালু", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, CH);
        else b = new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_shield)
                .setContentIntent(pi)
                .setOngoing(true);
        Notification n = b.build();

        if (Build.VERSION.SDK_INT >= 29) {
            int types = 0;
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            }
            if (types != 0) startForeground(ID, n, types);
            else startForeground(ID, n);
        } else {
            startForeground(ID, n);
        }
    }

    @Override
    public void onDestroy() {
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
