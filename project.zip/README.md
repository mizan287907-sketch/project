# জরুরি সুরক্ষা — Android (Kotlin)

## APK বানানো
1. Android Studio (Koala বা নতুন) ইনস্টল করুন।
2. File ▸ Open ▸ এই ফোল্ডারটি বেছে নিন। Gradle sync শেষ হতে দিন (প্রথমবার ইন্টারনেট লাগবে)।
3. ফোনে Developer options ▸ USB debugging চালু করে কেবল দিয়ে যুক্ত করুন, তারপর ▶ Run চাপুন।
   অথবা Build ▸ Build APK(s) করে APK ফোনে পাঠিয়ে ইনস্টল করুন।

## ফোনে প্রথমবার
- সব অনুমতি দিন (মাইক, SMS, ফোন, লোকেশন, নোটিফিকেশন)।
- Settings ▸ Apps ▸ জরুরি সুরক্ষা ▸ Battery ▸ "Unrestricted" দিন।
- Settings ▸ Apps ▸ Special access ▸ Full screen notifications চালু করুন (লক স্ক্রিনে লাল পর্দার জন্য)।
- Google অ্যাপে বাংলা (বাংলাদেশ) ভাষা ও অফলাইন স্পিচ প্যাক নামিয়ে রাখুন।
- নম্বর দিয়ে "দ্রুত মোড" চালু করে ⚠️ পরীক্ষা চাপুন এবং SMS ও কল ঠিক যাচ্ছে কিনা দেখুন।
