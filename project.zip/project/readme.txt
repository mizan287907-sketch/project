Emergency Guard / জরুরি সুরক্ষা — Android প্রজেক্ট (minSdk 21)
বিল্ড: java -jar apktool.jar b Project -o out.apk
সাইন: java -jar uber-apk-signer.jar -a out.apk --allowResign
UI/ভাষা: Project/assets/index.html
SMS/কল ক্রম: Project/smali_classes3/com/joruri/surokkha/Emergency.smali
