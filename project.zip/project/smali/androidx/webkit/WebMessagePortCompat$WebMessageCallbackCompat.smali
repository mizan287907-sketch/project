.class public abstract Landroidx/webkit/WebMessagePortCompat$WebMessageCallbackCompat;
.super Ljava/lang/Object;
.source "WebMessagePortCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/webkit/WebMessagePortCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "WebMessageCallbackCompat"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 68
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMessage(Landroidx/webkit/WebMessagePortCompat;Landroidx/webkit/WebMessageCompat;)V
    .locals 0
    .param p1, "port"    # Landroidx/webkit/WebMessagePortCompat;
    .param p2, "message"    # Landroidx/webkit/WebMessageCompat;

    .line 80
    return-void
.end method
